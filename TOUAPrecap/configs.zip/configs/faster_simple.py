_base_ = './faster_rcnn/faster-rcnn_r50_fpn_1x_coco.py'
model = dict(test_cfg=None)
