_base_ = './detr/detr_r50_8xb2-150e_coco.py'
model = dict(test_cfg=None)
